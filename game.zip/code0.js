gdjs.TitleCode = {};
gdjs.TitleCode.GDStartObjects1= [];
gdjs.TitleCode.GDStartObjects2= [];
gdjs.TitleCode.GDStartObjects3= [];
gdjs.TitleCode.GDTitleObjects1= [];
gdjs.TitleCode.GDTitleObjects2= [];
gdjs.TitleCode.GDTitleObjects3= [];
gdjs.TitleCode.GDSettingsObjects1= [];
gdjs.TitleCode.GDSettingsObjects2= [];
gdjs.TitleCode.GDSettingsObjects3= [];
gdjs.TitleCode.GDTitleMarkerObjects1= [];
gdjs.TitleCode.GDTitleMarkerObjects2= [];
gdjs.TitleCode.GDTitleMarkerObjects3= [];
gdjs.TitleCode.GDEffectsVolumeObjects1= [];
gdjs.TitleCode.GDEffectsVolumeObjects2= [];
gdjs.TitleCode.GDEffectsVolumeObjects3= [];
gdjs.TitleCode.GDBackObjects1= [];
gdjs.TitleCode.GDBackObjects2= [];
gdjs.TitleCode.GDBackObjects3= [];
gdjs.TitleCode.GDSettingsMarkerObjects1= [];
gdjs.TitleCode.GDSettingsMarkerObjects2= [];
gdjs.TitleCode.GDSettingsMarkerObjects3= [];
gdjs.TitleCode.GDMusicVolumeObjects1= [];
gdjs.TitleCode.GDMusicVolumeObjects2= [];
gdjs.TitleCode.GDMusicVolumeObjects3= [];
gdjs.TitleCode.GDQuitObjects1= [];
gdjs.TitleCode.GDQuitObjects2= [];
gdjs.TitleCode.GDQuitObjects3= [];
gdjs.TitleCode.GDInstructionsMarkerObjects1= [];
gdjs.TitleCode.GDInstructionsMarkerObjects2= [];
gdjs.TitleCode.GDInstructionsMarkerObjects3= [];
gdjs.TitleCode.GDInstructionsObjects1= [];
gdjs.TitleCode.GDInstructionsObjects2= [];
gdjs.TitleCode.GDInstructionsObjects3= [];
gdjs.TitleCode.GDRopeObjects1= [];
gdjs.TitleCode.GDRopeObjects2= [];
gdjs.TitleCode.GDRopeObjects3= [];
gdjs.TitleCode.GDSpidermanObjects1= [];
gdjs.TitleCode.GDSpidermanObjects2= [];
gdjs.TitleCode.GDSpidermanObjects3= [];
gdjs.TitleCode.GDFinishObjects1= [];
gdjs.TitleCode.GDFinishObjects2= [];
gdjs.TitleCode.GDFinishObjects3= [];
gdjs.TitleCode.GDCityBackgroundObjects1= [];
gdjs.TitleCode.GDCityBackgroundObjects2= [];
gdjs.TitleCode.GDCityBackgroundObjects3= [];
gdjs.TitleCode.GDBrickObjects1= [];
gdjs.TitleCode.GDBrickObjects2= [];
gdjs.TitleCode.GDBrickObjects3= [];
gdjs.TitleCode.GDBluePanelObjects1= [];
gdjs.TitleCode.GDBluePanelObjects2= [];
gdjs.TitleCode.GDBluePanelObjects3= [];
gdjs.TitleCode.GDEffectsSliderObjects1= [];
gdjs.TitleCode.GDEffectsSliderObjects2= [];
gdjs.TitleCode.GDEffectsSliderObjects3= [];
gdjs.TitleCode.GDMusicSliderObjects1= [];
gdjs.TitleCode.GDMusicSliderObjects2= [];
gdjs.TitleCode.GDMusicSliderObjects3= [];


gdjs.TitleCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("InstructionsMarker"), gdjs.TitleCode.GDInstructionsMarkerObjects2);
gdjs.copyArray(runtimeScene.getObjects("SettingsMarker"), gdjs.TitleCode.GDSettingsMarkerObjects2);
gdjs.copyArray(runtimeScene.getObjects("TitleMarker"), gdjs.TitleCode.GDTitleMarkerObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDTitleMarkerObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTitleMarkerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TitleCode.GDSettingsMarkerObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSettingsMarkerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TitleCode.GDInstructionsMarkerObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDInstructionsMarkerObjects2[i].hide();
}
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "mixkit-complicated-281.mp3", 3, true, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("music")), 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CityBackground"), gdjs.TitleCode.GDCityBackgroundObjects1);
{for(var i = 0, len = gdjs.TitleCode.GDCityBackgroundObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDCityBackgroundObjects1[i].setXOffset(gdjs.TitleCode.GDCityBackgroundObjects1[i].getXOffset() + (1));
}
}}

}


};gdjs.TitleCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.TitleCode.GDStartObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDStartObjects2.length;i<l;++i) {
    if ( gdjs.TitleCode.GDStartObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDStartObjects2[k] = gdjs.TitleCode.GDStartObjects2[i];
        ++k;
    }
}
gdjs.TitleCode.GDStartObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levels", false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.TitleCode.GDSettingsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDSettingsObjects2.length;i<l;++i) {
    if ( gdjs.TitleCode.GDSettingsObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDSettingsObjects2[k] = gdjs.TitleCode.GDSettingsObjects2[i];
        ++k;
    }
}
gdjs.TitleCode.GDSettingsObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SettingsMarker"), gdjs.TitleCode.GDSettingsMarkerObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "cameramove", (( gdjs.TitleCode.GDSettingsMarkerObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDSettingsMarkerObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "linear", 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.TitleCode.GDQuitObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDQuitObjects2.length;i<l;++i) {
    if ( gdjs.TitleCode.GDQuitObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDQuitObjects2[k] = gdjs.TitleCode.GDQuitObjects2[i];
        ++k;
    }
}
gdjs.TitleCode.GDQuitObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("InstructionsMarker"), gdjs.TitleCode.GDInstructionsMarkerObjects2);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "cameramove", (( gdjs.TitleCode.GDInstructionsMarkerObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDInstructionsMarkerObjects2[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "linear", 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EffectsSlider"), gdjs.TitleCode.GDEffectsSliderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDEffectsSliderObjects2.length;i<l;++i) {
    if ( gdjs.TitleCode.GDEffectsSliderObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDEffectsSliderObjects2[k] = gdjs.TitleCode.GDEffectsSliderObjects2[i];
        ++k;
    }
}
gdjs.TitleCode.GDEffectsSliderObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDEffectsSliderObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects").setNumber((( gdjs.TitleCode.GDEffectsSliderObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDEffectsSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 2, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("MusicSlider"), gdjs.TitleCode.GDMusicSliderObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDMusicSliderObjects2.length;i<l;++i) {
    if ( gdjs.TitleCode.GDMusicSliderObjects2[i].IsBeingDragged((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDMusicSliderObjects2[k] = gdjs.TitleCode.GDMusicSliderObjects2[i];
        ++k;
    }
}
gdjs.TitleCode.GDMusicSliderObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDMusicSliderObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("music").setNumber((( gdjs.TitleCode.GDMusicSliderObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDMusicSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}{gdjs.evtTools.sound.setSoundOnChannelVolume(runtimeScene, 3, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("music")));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.TitleCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TitleCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.TitleCode.GDBackObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.TitleCode.GDBackObjects1[k] = gdjs.TitleCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.TitleCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TitleMarker"), gdjs.TitleCode.GDTitleMarkerObjects1);
{gdjs.evtTools.tween.tweenCamera2(runtimeScene, "cameramove", (( gdjs.TitleCode.GDTitleMarkerObjects1.length === 0 ) ? 0 :gdjs.TitleCode.GDTitleMarkerObjects1[0].getCenterXInScene()), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), "", "linear", 1);
}}

}


};gdjs.TitleCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.TitleCode.GDBrickObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.TitleCode.GDSpidermanObjects2);
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.TitleCode.GDSpidermanObjects2.length !== 0 ? gdjs.TitleCode.GDSpidermanObjects2[0] : null), (gdjs.TitleCode.GDBrickObjects2.length !== 0 ? gdjs.TitleCode.GDBrickObjects2[0] : null));
}{for(var i = 0, len = gdjs.TitleCode.GDBrickObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDBrickObjects2[i].getBehavior("Physics2").addRopeJoint((gdjs.TitleCode.GDBrickObjects2[i].getPointX("Grab")), (gdjs.TitleCode.GDBrickObjects2[i].getPointY("Grab")), (gdjs.TitleCode.GDSpidermanObjects2.length !== 0 ? gdjs.TitleCode.GDSpidermanObjects2[0] : null), (( gdjs.TitleCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDSpidermanObjects2[0].getPointX("Grab")), (( gdjs.TitleCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDSpidermanObjects2[0].getPointY("Grab")), -(1), false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.TitleCode.GDBrickObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rope"), gdjs.TitleCode.GDRopeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.TitleCode.GDSpidermanObjects1);
{for(var i = 0, len = gdjs.TitleCode.GDRopeObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDRopeObjects1[i].drawLine((( gdjs.TitleCode.GDSpidermanObjects1.length === 0 ) ? 0 :gdjs.TitleCode.GDSpidermanObjects1[0].getPointX("Grab")), (( gdjs.TitleCode.GDSpidermanObjects1.length === 0 ) ? 0 :gdjs.TitleCode.GDSpidermanObjects1[0].getPointY("Grab")), (( gdjs.TitleCode.GDBrickObjects1.length === 0 ) ? 0 :gdjs.TitleCode.GDBrickObjects1[0].getPointX("Grab")), (( gdjs.TitleCode.GDBrickObjects1.length === 0 ) ? 0 :gdjs.TitleCode.GDBrickObjects1[0].getPointY("Grab")), 3);
}
}}

}


};gdjs.TitleCode.eventsList3 = function(runtimeScene) {

{


gdjs.TitleCode.eventsList0(runtimeScene);
}


{


gdjs.TitleCode.eventsList1(runtimeScene);
}


{


gdjs.TitleCode.eventsList2(runtimeScene);
}


};

gdjs.TitleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TitleCode.GDStartObjects1.length = 0;
gdjs.TitleCode.GDStartObjects2.length = 0;
gdjs.TitleCode.GDStartObjects3.length = 0;
gdjs.TitleCode.GDTitleObjects1.length = 0;
gdjs.TitleCode.GDTitleObjects2.length = 0;
gdjs.TitleCode.GDTitleObjects3.length = 0;
gdjs.TitleCode.GDSettingsObjects1.length = 0;
gdjs.TitleCode.GDSettingsObjects2.length = 0;
gdjs.TitleCode.GDSettingsObjects3.length = 0;
gdjs.TitleCode.GDTitleMarkerObjects1.length = 0;
gdjs.TitleCode.GDTitleMarkerObjects2.length = 0;
gdjs.TitleCode.GDTitleMarkerObjects3.length = 0;
gdjs.TitleCode.GDEffectsVolumeObjects1.length = 0;
gdjs.TitleCode.GDEffectsVolumeObjects2.length = 0;
gdjs.TitleCode.GDEffectsVolumeObjects3.length = 0;
gdjs.TitleCode.GDBackObjects1.length = 0;
gdjs.TitleCode.GDBackObjects2.length = 0;
gdjs.TitleCode.GDBackObjects3.length = 0;
gdjs.TitleCode.GDSettingsMarkerObjects1.length = 0;
gdjs.TitleCode.GDSettingsMarkerObjects2.length = 0;
gdjs.TitleCode.GDSettingsMarkerObjects3.length = 0;
gdjs.TitleCode.GDMusicVolumeObjects1.length = 0;
gdjs.TitleCode.GDMusicVolumeObjects2.length = 0;
gdjs.TitleCode.GDMusicVolumeObjects3.length = 0;
gdjs.TitleCode.GDQuitObjects1.length = 0;
gdjs.TitleCode.GDQuitObjects2.length = 0;
gdjs.TitleCode.GDQuitObjects3.length = 0;
gdjs.TitleCode.GDInstructionsMarkerObjects1.length = 0;
gdjs.TitleCode.GDInstructionsMarkerObjects2.length = 0;
gdjs.TitleCode.GDInstructionsMarkerObjects3.length = 0;
gdjs.TitleCode.GDInstructionsObjects1.length = 0;
gdjs.TitleCode.GDInstructionsObjects2.length = 0;
gdjs.TitleCode.GDInstructionsObjects3.length = 0;
gdjs.TitleCode.GDRopeObjects1.length = 0;
gdjs.TitleCode.GDRopeObjects2.length = 0;
gdjs.TitleCode.GDRopeObjects3.length = 0;
gdjs.TitleCode.GDSpidermanObjects1.length = 0;
gdjs.TitleCode.GDSpidermanObjects2.length = 0;
gdjs.TitleCode.GDSpidermanObjects3.length = 0;
gdjs.TitleCode.GDFinishObjects1.length = 0;
gdjs.TitleCode.GDFinishObjects2.length = 0;
gdjs.TitleCode.GDFinishObjects3.length = 0;
gdjs.TitleCode.GDCityBackgroundObjects1.length = 0;
gdjs.TitleCode.GDCityBackgroundObjects2.length = 0;
gdjs.TitleCode.GDCityBackgroundObjects3.length = 0;
gdjs.TitleCode.GDBrickObjects1.length = 0;
gdjs.TitleCode.GDBrickObjects2.length = 0;
gdjs.TitleCode.GDBrickObjects3.length = 0;
gdjs.TitleCode.GDBluePanelObjects1.length = 0;
gdjs.TitleCode.GDBluePanelObjects2.length = 0;
gdjs.TitleCode.GDBluePanelObjects3.length = 0;
gdjs.TitleCode.GDEffectsSliderObjects1.length = 0;
gdjs.TitleCode.GDEffectsSliderObjects2.length = 0;
gdjs.TitleCode.GDEffectsSliderObjects3.length = 0;
gdjs.TitleCode.GDMusicSliderObjects1.length = 0;
gdjs.TitleCode.GDMusicSliderObjects2.length = 0;
gdjs.TitleCode.GDMusicSliderObjects3.length = 0;

gdjs.TitleCode.eventsList3(runtimeScene);

return;

}

gdjs['TitleCode'] = gdjs.TitleCode;
