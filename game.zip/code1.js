gdjs.LevelsCode = {};
gdjs.LevelsCode.GDContinueTextObjects1= [];
gdjs.LevelsCode.GDContinueTextObjects2= [];
gdjs.LevelsCode.GDContinueTextObjects3= [];
gdjs.LevelsCode.GDContinueTextObjects4= [];
gdjs.LevelsCode.GDContinueTextObjects5= [];
gdjs.LevelsCode.GDSpeedTextObjects1= [];
gdjs.LevelsCode.GDSpeedTextObjects2= [];
gdjs.LevelsCode.GDSpeedTextObjects3= [];
gdjs.LevelsCode.GDSpeedTextObjects4= [];
gdjs.LevelsCode.GDSpeedTextObjects5= [];
gdjs.LevelsCode.GDLevelTextObjects1= [];
gdjs.LevelsCode.GDLevelTextObjects2= [];
gdjs.LevelsCode.GDLevelTextObjects3= [];
gdjs.LevelsCode.GDLevelTextObjects4= [];
gdjs.LevelsCode.GDLevelTextObjects5= [];
gdjs.LevelsCode.GDSuccessTextObjects1= [];
gdjs.LevelsCode.GDSuccessTextObjects2= [];
gdjs.LevelsCode.GDSuccessTextObjects3= [];
gdjs.LevelsCode.GDSuccessTextObjects4= [];
gdjs.LevelsCode.GDSuccessTextObjects5= [];
gdjs.LevelsCode.GDParticlesEmitterWinObjects1= [];
gdjs.LevelsCode.GDParticlesEmitterWinObjects2= [];
gdjs.LevelsCode.GDParticlesEmitterWinObjects3= [];
gdjs.LevelsCode.GDParticlesEmitterWinObjects4= [];
gdjs.LevelsCode.GDParticlesEmitterWinObjects5= [];
gdjs.LevelsCode.GDTrampolineObjects1= [];
gdjs.LevelsCode.GDTrampolineObjects2= [];
gdjs.LevelsCode.GDTrampolineObjects3= [];
gdjs.LevelsCode.GDTrampolineObjects4= [];
gdjs.LevelsCode.GDTrampolineObjects5= [];
gdjs.LevelsCode.GDDistanceLeftObjects1= [];
gdjs.LevelsCode.GDDistanceLeftObjects2= [];
gdjs.LevelsCode.GDDistanceLeftObjects3= [];
gdjs.LevelsCode.GDDistanceLeftObjects4= [];
gdjs.LevelsCode.GDDistanceLeftObjects5= [];
gdjs.LevelsCode.GDArrowDistanceLeftObjects1= [];
gdjs.LevelsCode.GDArrowDistanceLeftObjects2= [];
gdjs.LevelsCode.GDArrowDistanceLeftObjects3= [];
gdjs.LevelsCode.GDArrowDistanceLeftObjects4= [];
gdjs.LevelsCode.GDArrowDistanceLeftObjects5= [];
gdjs.LevelsCode.GDGreenGoblinObjects1= [];
gdjs.LevelsCode.GDGreenGoblinObjects2= [];
gdjs.LevelsCode.GDGreenGoblinObjects3= [];
gdjs.LevelsCode.GDGreenGoblinObjects4= [];
gdjs.LevelsCode.GDGreenGoblinObjects5= [];
gdjs.LevelsCode.GDStarTextObjects1= [];
gdjs.LevelsCode.GDStarTextObjects2= [];
gdjs.LevelsCode.GDStarTextObjects3= [];
gdjs.LevelsCode.GDStarTextObjects4= [];
gdjs.LevelsCode.GDStarTextObjects5= [];
gdjs.LevelsCode.GDStarObjects1= [];
gdjs.LevelsCode.GDStarObjects2= [];
gdjs.LevelsCode.GDStarObjects3= [];
gdjs.LevelsCode.GDStarObjects4= [];
gdjs.LevelsCode.GDStarObjects5= [];
gdjs.LevelsCode.GDRopeObjects1= [];
gdjs.LevelsCode.GDRopeObjects2= [];
gdjs.LevelsCode.GDRopeObjects3= [];
gdjs.LevelsCode.GDRopeObjects4= [];
gdjs.LevelsCode.GDRopeObjects5= [];
gdjs.LevelsCode.GDSpidermanObjects1= [];
gdjs.LevelsCode.GDSpidermanObjects2= [];
gdjs.LevelsCode.GDSpidermanObjects3= [];
gdjs.LevelsCode.GDSpidermanObjects4= [];
gdjs.LevelsCode.GDSpidermanObjects5= [];
gdjs.LevelsCode.GDFinishObjects1= [];
gdjs.LevelsCode.GDFinishObjects2= [];
gdjs.LevelsCode.GDFinishObjects3= [];
gdjs.LevelsCode.GDFinishObjects4= [];
gdjs.LevelsCode.GDFinishObjects5= [];
gdjs.LevelsCode.GDCityBackgroundObjects1= [];
gdjs.LevelsCode.GDCityBackgroundObjects2= [];
gdjs.LevelsCode.GDCityBackgroundObjects3= [];
gdjs.LevelsCode.GDCityBackgroundObjects4= [];
gdjs.LevelsCode.GDCityBackgroundObjects5= [];
gdjs.LevelsCode.GDBrickObjects1= [];
gdjs.LevelsCode.GDBrickObjects2= [];
gdjs.LevelsCode.GDBrickObjects3= [];
gdjs.LevelsCode.GDBrickObjects4= [];
gdjs.LevelsCode.GDBrickObjects5= [];
gdjs.LevelsCode.GDBluePanelObjects1= [];
gdjs.LevelsCode.GDBluePanelObjects2= [];
gdjs.LevelsCode.GDBluePanelObjects3= [];
gdjs.LevelsCode.GDBluePanelObjects4= [];
gdjs.LevelsCode.GDBluePanelObjects5= [];
gdjs.LevelsCode.GDEffectsSliderObjects1= [];
gdjs.LevelsCode.GDEffectsSliderObjects2= [];
gdjs.LevelsCode.GDEffectsSliderObjects3= [];
gdjs.LevelsCode.GDEffectsSliderObjects4= [];
gdjs.LevelsCode.GDEffectsSliderObjects5= [];
gdjs.LevelsCode.GDMusicSliderObjects1= [];
gdjs.LevelsCode.GDMusicSliderObjects2= [];
gdjs.LevelsCode.GDMusicSliderObjects3= [];
gdjs.LevelsCode.GDMusicSliderObjects4= [];
gdjs.LevelsCode.GDMusicSliderObjects5= [];


gdjs.LevelsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 2);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}}

}


};gdjs.LevelsCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LevelText"), gdjs.LevelsCode.GDLevelTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("StarText"), gdjs.LevelsCode.GDStarTextObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Level" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)), 0, 0, 0);
}{for(var i = 0, len = gdjs.LevelsCode.GDLevelTextObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDLevelTextObjects2[i].setString("Level " + gdjs.evtTools.string.newLine() + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDStarTextObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDStarTextObjects2[i].setString("Stars Collected" + gdjs.evtTools.string.newLine() + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Ending");
}
{ //Subevents
gdjs.LevelsCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.LevelsCode.GDSpidermanObjects1.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects1[0].getCenterXInScene()), "", 0);
}}

}


};gdjs.LevelsCode.eventsList3 = function(runtimeScene) {

{


gdjs.LevelsCode.eventsList1(runtimeScene);
}


{


gdjs.LevelsCode.eventsList2(runtimeScene);
}


};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects2});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDStarObjects2Objects = Hashtable.newFrom({"Star": gdjs.LevelsCode.GDStarObjects2});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects2});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDTrampolineObjects2Objects = Hashtable.newFrom({"Trampoline": gdjs.LevelsCode.GDTrampolineObjects2});
gdjs.LevelsCode.asyncCallback11990180 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects3);

{for(var i = 0, len = gdjs.LevelsCode.GDSpidermanObjects3.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpidermanObjects3[i].getBehavior("Animation").setAnimationName("Falling");
}
}}
gdjs.LevelsCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.LevelsCode.GDSpidermanObjects2) asyncObjectsList.addObject("Spiderman", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.LevelsCode.asyncCallback11990180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.LevelsCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.LevelsCode.GDDistanceLeftObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelsCode.GDDistanceLeftObjects2.length;i<l;++i) {
    if ( !(gdjs.LevelsCode.GDDistanceLeftObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelsCode.GDDistanceLeftObjects2[k] = gdjs.LevelsCode.GDDistanceLeftObjects2[i];
        ++k;
    }
}
gdjs.LevelsCode.GDDistanceLeftObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ArrowDistanceLeft"), gdjs.LevelsCode.GDArrowDistanceLeftObjects2);
/* Reuse gdjs.LevelsCode.GDDistanceLeftObjects2 */
{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.LevelsCode.GDArrowDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDArrowDistanceLeftObjects2[i].hide(false);
}
}}

}


};gdjs.LevelsCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Star"), gdjs.LevelsCode.GDStarObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects, gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDStarObjects2Objects, 100, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11988356);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelsCode.GDStarObjects2 */
gdjs.copyArray(runtimeScene.getObjects("StarText"), gdjs.LevelsCode.GDStarTextObjects2);
{for(var i = 0, len = gdjs.LevelsCode.GDStarObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDStarObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.LevelsCode.GDStarTextObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDStarTextObjects2[i].setString("Stars Collected" + gdjs.evtTools.string.newLine() + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Trampoline"), gdjs.LevelsCode.GDTrampolineObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects, "Physics2", gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDTrampolineObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11989356);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelsCode.GDSpidermanObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-electric-pop-2365.wav", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")), 1);
}{for(var i = 0, len = gdjs.LevelsCode.GDSpidermanObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpidermanObjects2[i].getBehavior("Animation").setAnimationName("Hitting Trampoline");
}
}
{ //Subevents
gdjs.LevelsCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ArrowDistanceLeft"), gdjs.LevelsCode.GDArrowDistanceLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("CityBackground"), gdjs.LevelsCode.GDCityBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("DistanceLeft"), gdjs.LevelsCode.GDDistanceLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Finish"), gdjs.LevelsCode.GDFinishObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpeedText"), gdjs.LevelsCode.GDSpeedTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);
{for(var i = 0, len = gdjs.LevelsCode.GDArrowDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDArrowDistanceLeftObjects2[i].setCenterYInScene((( gdjs.LevelsCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects2[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects2[i].setX((( gdjs.LevelsCode.GDArrowDistanceLeftObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDArrowDistanceLeftObjects2[0].getPointX("")) - (gdjs.LevelsCode.GDDistanceLeftObjects2[i].getWidth()) - 20);
}
}{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects2[i].setCenterYInScene((( gdjs.LevelsCode.GDArrowDistanceLeftObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDArrowDistanceLeftObjects2[0].getCenterYInScene()));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDCityBackgroundObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDCityBackgroundObjects2[i].setXOffset(gdjs.LevelsCode.GDCityBackgroundObjects2[i].getXOffset() + (1));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects2[i].setString(gdjs.evtTools.common.toString(Math.round((( gdjs.LevelsCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects2[0].getDistanceToObject((gdjs.LevelsCode.GDFinishObjects2.length !== 0 ? gdjs.LevelsCode.GDFinishObjects2[0] : null))) / 100)));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDSpeedTextObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpeedTextObjects2[i].setString("Speed " + gdjs.evtTools.string.newLine() + gdjs.evtTools.common.toString(Math.round(Math.abs((( gdjs.LevelsCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects2[0].getBehavior("Physics2").getLinearVelocityX())))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Finish"), gdjs.LevelsCode.GDFinishObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.LevelsCode.GDFinishObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDFinishObjects2[0].getX()) > (( gdjs.LevelsCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects2[0].getPointX("")) + 300);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DistanceLeft"), gdjs.LevelsCode.GDDistanceLeftObjects2);
/* Reuse gdjs.LevelsCode.GDFinishObjects2 */
/* Reuse gdjs.LevelsCode.GDSpidermanObjects2 */
{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects2[i].setString(gdjs.evtTools.common.toString(Math.round((( gdjs.LevelsCode.GDSpidermanObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects2[0].getDistanceToObject((gdjs.LevelsCode.GDFinishObjects2.length !== 0 ? gdjs.LevelsCode.GDFinishObjects2[0] : null))) / 100)));
}
}
{ //Subevents
gdjs.LevelsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DistanceLeft"), gdjs.LevelsCode.GDDistanceLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Finish"), gdjs.LevelsCode.GDFinishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.LevelsCode.GDFinishObjects1.length === 0 ) ? 0 :gdjs.LevelsCode.GDFinishObjects1[0].getX()) < (( gdjs.LevelsCode.GDSpidermanObjects1.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects1[0].getPointX("")) + 300);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelsCode.GDDistanceLeftObjects1.length;i<l;++i) {
    if ( gdjs.LevelsCode.GDDistanceLeftObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.LevelsCode.GDDistanceLeftObjects1[k] = gdjs.LevelsCode.GDDistanceLeftObjects1[i];
        ++k;
    }
}
gdjs.LevelsCode.GDDistanceLeftObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ArrowDistanceLeft"), gdjs.LevelsCode.GDArrowDistanceLeftObjects1);
/* Reuse gdjs.LevelsCode.GDDistanceLeftObjects1 */
{for(var i = 0, len = gdjs.LevelsCode.GDDistanceLeftObjects1.length ;i < len;++i) {
    gdjs.LevelsCode.GDDistanceLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.LevelsCode.GDArrowDistanceLeftObjects1.length ;i < len;++i) {
    gdjs.LevelsCode.GDArrowDistanceLeftObjects1[i].hide();
}
}}

}


};gdjs.LevelsCode.eventsList7 = function(runtimeScene) {

};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects4Objects = Hashtable.newFrom({"Brick": gdjs.LevelsCode.GDBrickObjects4});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects4Objects = Hashtable.newFrom({"Brick": gdjs.LevelsCode.GDBrickObjects4});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects4Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects4});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects3Objects = Hashtable.newFrom({"Brick": gdjs.LevelsCode.GDBrickObjects3});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects3Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects3});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects3Objects = Hashtable.newFrom({"Brick": gdjs.LevelsCode.GDBrickObjects3});
gdjs.LevelsCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.LevelsCode.GDBrickObjects4);
gdjs.copyArray(gdjs.LevelsCode.GDSpidermanObjects3, gdjs.LevelsCode.GDSpidermanObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects4Objects, (( gdjs.LevelsCode.GDSpidermanObjects4.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects4[0].getPointX("")), (( gdjs.LevelsCode.GDSpidermanObjects4.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects4[0].getPointY("")), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects4Objects, gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects4Objects, 500, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.LevelsCode.GDBrickObjects4 */
/* Reuse gdjs.LevelsCode.GDSpidermanObjects4 */
{for(var i = 0, len = gdjs.LevelsCode.GDBrickObjects4.length ;i < len;++i) {
    gdjs.LevelsCode.GDBrickObjects4[i].getBehavior("Physics2").addRopeJoint((gdjs.LevelsCode.GDBrickObjects4[i].getCenterXInScene()), (gdjs.LevelsCode.GDBrickObjects4[i].getCenterYInScene()), (gdjs.LevelsCode.GDSpidermanObjects4.length !== 0 ? gdjs.LevelsCode.GDSpidermanObjects4[0] : null), (( gdjs.LevelsCode.GDSpidermanObjects4.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects4[0].getCenterXInScene()), (( gdjs.LevelsCode.GDSpidermanObjects4.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects4[0].getCenterYInScene()), -(1), false, runtimeScene.getScene().getVariables().getFromIndex(1));
}
}{for(var i = 0, len = gdjs.LevelsCode.GDBrickObjects4.length ;i < len;++i) {
    gdjs.LevelsCode.GDBrickObjects4[i].setOpacity(250);
}
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.LevelsCode.GDSpidermanObjects4.length !== 0 ? gdjs.LevelsCode.GDSpidermanObjects4[0] : null), (gdjs.LevelsCode.GDBrickObjects4.length !== 0 ? gdjs.LevelsCode.GDBrickObjects4[0] : null));
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
}{for(var i = 0, len = gdjs.LevelsCode.GDBrickObjects4.length ;i < len;++i) {
    gdjs.LevelsCode.GDBrickObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 5, 5, 10, 10, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets\\Audio\\star.ogg", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")), 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.LevelsCode.GDBrickObjects3);
/* Reuse gdjs.LevelsCode.GDSpidermanObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects3Objects, gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects3Objects, 500, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LevelsCode.GDBrickObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Rope"), gdjs.LevelsCode.GDRopeObjects3);
/* Reuse gdjs.LevelsCode.GDSpidermanObjects3 */
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects3Objects, (gdjs.LevelsCode.GDSpidermanObjects3.length !== 0 ? gdjs.LevelsCode.GDSpidermanObjects3[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelsCode.GDRopeObjects3.length ;i < len;++i) {
    gdjs.LevelsCode.GDRopeObjects3[i].drawLine((( gdjs.LevelsCode.GDSpidermanObjects3.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects3[0].getPointX("Arm")), (( gdjs.LevelsCode.GDSpidermanObjects3.length === 0 ) ? 0 :gdjs.LevelsCode.GDSpidermanObjects3[0].getPointY("Arm")), (( gdjs.LevelsCode.GDBrickObjects3.length === 0 ) ? 0 :gdjs.LevelsCode.GDBrickObjects3[0].getPointX("Grab")), (( gdjs.LevelsCode.GDBrickObjects3.length === 0 ) ? 0 :gdjs.LevelsCode.GDBrickObjects3[0].getPointY("Grab")), 2);
}
}}

}


};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects2Objects = Hashtable.newFrom({"Brick": gdjs.LevelsCode.GDBrickObjects2});
gdjs.LevelsCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Brick"), gdjs.LevelsCode.GDBrickObjects2);
/* Reuse gdjs.LevelsCode.GDSpidermanObjects2 */
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDBrickObjects2Objects, (gdjs.LevelsCode.GDSpidermanObjects2.length !== 0 ? gdjs.LevelsCode.GDSpidermanObjects2[0] : null), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.LevelsCode.GDBrickObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDBrickObjects2[i].setOpacity(255);
}
}{gdjs.evtTools.linkedObjects.removeLinkBetween(runtimeScene, (gdjs.LevelsCode.GDBrickObjects2.length !== 0 ? gdjs.LevelsCode.GDBrickObjects2[0] : null), (gdjs.LevelsCode.GDSpidermanObjects2.length !== 0 ? gdjs.LevelsCode.GDSpidermanObjects2[0] : null));
}{for(var i = 0, len = gdjs.LevelsCode.GDBrickObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDBrickObjects2[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.LevelsCode.GDSpidermanObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpidermanObjects2[i].getBehavior("Physics2").applyImpulse((gdjs.LevelsCode.GDSpidermanObjects2[i].getBehavior("Physics2").getLinearVelocityX()) * 0.001, (gdjs.LevelsCode.GDSpidermanObjects2[i].getBehavior("Physics2").getLinearVelocityY()) * 0.001, (gdjs.LevelsCode.GDSpidermanObjects2[i].getCenterXInScene()), (gdjs.LevelsCode.GDSpidermanObjects2[i].getCenterYInScene()));
}
}}

}


};gdjs.LevelsCode.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects3);
{for(var i = 0, len = gdjs.LevelsCode.GDSpidermanObjects3.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpidermanObjects3[i].getBehavior("Animation").setAnimationName("Swinging");
}
}
{ //Subevents
gdjs.LevelsCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);
{for(var i = 0, len = gdjs.LevelsCode.GDSpidermanObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDSpidermanObjects2[i].getBehavior("Animation").setAnimationName("Falling");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-air-woosh-1489.wav", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")), 1);
}
{ //Subevents
gdjs.LevelsCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene) >= 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelsCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) < runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}}

}


};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects2});
gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDGreenGoblinObjects2Objects = Hashtable.newFrom({"GreenGoblin": gdjs.LevelsCode.GDGreenGoblinObjects2});
gdjs.LevelsCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) < runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}}

}


};gdjs.LevelsCode.eventsList14 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelsCode.GDSpidermanObjects3.length;i<l;++i) {
    if ( gdjs.LevelsCode.GDSpidermanObjects3[i].getY() > gdjs.evtTools.camera.getCameraHeight(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.LevelsCode.GDSpidermanObjects3[k] = gdjs.LevelsCode.GDSpidermanObjects3[i];
        ++k;
    }
}
gdjs.LevelsCode.GDSpidermanObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levels", true);
}
{ //Subevents
gdjs.LevelsCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.LevelsCode.GDGreenGoblinObjects1, gdjs.LevelsCode.GDGreenGoblinObjects2);

gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.objectsCollide(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects2Objects, "Physics2", gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDGreenGoblinObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12007164);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levels", true);
}
{ //Subevents
gdjs.LevelsCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects1Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects1});
gdjs.LevelsCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Finish"), gdjs.LevelsCode.GDFinishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LevelsCode.GDSpidermanObjects1.length;i<l;++i) {
    if ( gdjs.LevelsCode.GDSpidermanObjects1[i].getCenterXInScene() >= (( gdjs.LevelsCode.GDFinishObjects1.length === 0 ) ? 0 :gdjs.LevelsCode.GDFinishObjects1[0].getX()) ) {
        isConditionTrue_0 = true;
        gdjs.LevelsCode.GDSpidermanObjects1[k] = gdjs.LevelsCode.GDSpidermanObjects1[i];
        ++k;
    }
}
gdjs.LevelsCode.GDSpidermanObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LevelsCode.GDSpidermanObjects1 */
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "sceneFinish");
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "mixkit-retro-game-notification-212.wav", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")), 1);
}{gdjs.physics2.setTimeScale(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects1Objects, "Physics2", 0.25);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}}

}


};gdjs.LevelsCode.eventsList16 = function(runtimeScene) {

{


gdjs.LevelsCode.eventsList11(runtimeScene);
}


{


gdjs.LevelsCode.eventsList14(runtimeScene);
}


{


gdjs.LevelsCode.eventsList15(runtimeScene);
}


};gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects3Objects = Hashtable.newFrom({"Spiderman": gdjs.LevelsCode.GDSpidermanObjects3});
gdjs.LevelsCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Spiderman"), gdjs.LevelsCode.GDSpidermanObjects3);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\Audio\\applause.wav", 2, false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("effects")), 1);
}{gdjs.physics2.setTimeScale(gdjs.LevelsCode.mapOfGDgdjs_9546LevelsCode_9546GDSpidermanObjects3Objects, "Physics2", 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SuccessText"), gdjs.LevelsCode.GDSuccessTextObjects3);
{for(var i = 0, len = gdjs.LevelsCode.GDSuccessTextObjects3.length ;i < len;++i) {
    gdjs.LevelsCode.GDSuccessTextObjects3[i].setString("Congratulations!" + gdjs.evtTools.string.newLine() + "You won with " + runtimeScene.getGame().getVariables().getFromIndex(1).getAsString() + " stars!");
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SuccessText"), gdjs.LevelsCode.GDSuccessTextObjects3);
{for(var i = 0, len = gdjs.LevelsCode.GDSuccessTextObjects3.length ;i < len;++i) {
    gdjs.LevelsCode.GDSuccessTextObjects3[i].setString("Level cleared!" + gdjs.evtTools.string.newLine() + "Next level >>>");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BluePanel"), gdjs.LevelsCode.GDBluePanelObjects2);
gdjs.copyArray(runtimeScene.getObjects("ParticlesEmitterWin"), gdjs.LevelsCode.GDParticlesEmitterWinObjects2);
gdjs.copyArray(runtimeScene.getObjects("SuccessText"), gdjs.LevelsCode.GDSuccessTextObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Ending");
}{for(var i = 0, len = gdjs.LevelsCode.GDParticlesEmitterWinObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDParticlesEmitterWinObjects2[i].startEmission();
}
}{for(var i = 0, len = gdjs.LevelsCode.GDSuccessTextObjects2.length ;i < len;++i) {
    gdjs.LevelsCode.GDSuccessTextObjects2[i].setCenterPositionInScene((( gdjs.LevelsCode.GDBluePanelObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDBluePanelObjects2[0].getCenterXInScene()),(( gdjs.LevelsCode.GDBluePanelObjects2.length === 0 ) ? 0 :gdjs.LevelsCode.GDBluePanelObjects2[0].getCenterYInScene()));
}
}}

}


};gdjs.LevelsCode.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", true);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) == 10);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Levels", true);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


};gdjs.LevelsCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "sceneFinish") >= 0.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelsCode.eventsList17(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "sceneFinish") >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "sceneFinish") >= 1.2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(3), true);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelsCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.LevelsCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.LevelsCode.eventsList21 = function(runtimeScene) {

{


gdjs.LevelsCode.eventsList3(runtimeScene);
}


{


gdjs.LevelsCode.eventsList6(runtimeScene);
}


{


gdjs.LevelsCode.eventsList7(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GreenGoblin"), gdjs.LevelsCode.GDGreenGoblinObjects1);
{for(var i = 0, len = gdjs.LevelsCode.GDGreenGoblinObjects1.length ;i < len;++i) {
    gdjs.LevelsCode.GDGreenGoblinObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(9999999999999999999999999999999999999999999999999999999999999999999999999, 5, 0, 5, 0.02, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.LevelsCode.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.LevelsCode.eventsList20(runtimeScene);
}


};

gdjs.LevelsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LevelsCode.GDContinueTextObjects1.length = 0;
gdjs.LevelsCode.GDContinueTextObjects2.length = 0;
gdjs.LevelsCode.GDContinueTextObjects3.length = 0;
gdjs.LevelsCode.GDContinueTextObjects4.length = 0;
gdjs.LevelsCode.GDContinueTextObjects5.length = 0;
gdjs.LevelsCode.GDSpeedTextObjects1.length = 0;
gdjs.LevelsCode.GDSpeedTextObjects2.length = 0;
gdjs.LevelsCode.GDSpeedTextObjects3.length = 0;
gdjs.LevelsCode.GDSpeedTextObjects4.length = 0;
gdjs.LevelsCode.GDSpeedTextObjects5.length = 0;
gdjs.LevelsCode.GDLevelTextObjects1.length = 0;
gdjs.LevelsCode.GDLevelTextObjects2.length = 0;
gdjs.LevelsCode.GDLevelTextObjects3.length = 0;
gdjs.LevelsCode.GDLevelTextObjects4.length = 0;
gdjs.LevelsCode.GDLevelTextObjects5.length = 0;
gdjs.LevelsCode.GDSuccessTextObjects1.length = 0;
gdjs.LevelsCode.GDSuccessTextObjects2.length = 0;
gdjs.LevelsCode.GDSuccessTextObjects3.length = 0;
gdjs.LevelsCode.GDSuccessTextObjects4.length = 0;
gdjs.LevelsCode.GDSuccessTextObjects5.length = 0;
gdjs.LevelsCode.GDParticlesEmitterWinObjects1.length = 0;
gdjs.LevelsCode.GDParticlesEmitterWinObjects2.length = 0;
gdjs.LevelsCode.GDParticlesEmitterWinObjects3.length = 0;
gdjs.LevelsCode.GDParticlesEmitterWinObjects4.length = 0;
gdjs.LevelsCode.GDParticlesEmitterWinObjects5.length = 0;
gdjs.LevelsCode.GDTrampolineObjects1.length = 0;
gdjs.LevelsCode.GDTrampolineObjects2.length = 0;
gdjs.LevelsCode.GDTrampolineObjects3.length = 0;
gdjs.LevelsCode.GDTrampolineObjects4.length = 0;
gdjs.LevelsCode.GDTrampolineObjects5.length = 0;
gdjs.LevelsCode.GDDistanceLeftObjects1.length = 0;
gdjs.LevelsCode.GDDistanceLeftObjects2.length = 0;
gdjs.LevelsCode.GDDistanceLeftObjects3.length = 0;
gdjs.LevelsCode.GDDistanceLeftObjects4.length = 0;
gdjs.LevelsCode.GDDistanceLeftObjects5.length = 0;
gdjs.LevelsCode.GDArrowDistanceLeftObjects1.length = 0;
gdjs.LevelsCode.GDArrowDistanceLeftObjects2.length = 0;
gdjs.LevelsCode.GDArrowDistanceLeftObjects3.length = 0;
gdjs.LevelsCode.GDArrowDistanceLeftObjects4.length = 0;
gdjs.LevelsCode.GDArrowDistanceLeftObjects5.length = 0;
gdjs.LevelsCode.GDGreenGoblinObjects1.length = 0;
gdjs.LevelsCode.GDGreenGoblinObjects2.length = 0;
gdjs.LevelsCode.GDGreenGoblinObjects3.length = 0;
gdjs.LevelsCode.GDGreenGoblinObjects4.length = 0;
gdjs.LevelsCode.GDGreenGoblinObjects5.length = 0;
gdjs.LevelsCode.GDStarTextObjects1.length = 0;
gdjs.LevelsCode.GDStarTextObjects2.length = 0;
gdjs.LevelsCode.GDStarTextObjects3.length = 0;
gdjs.LevelsCode.GDStarTextObjects4.length = 0;
gdjs.LevelsCode.GDStarTextObjects5.length = 0;
gdjs.LevelsCode.GDStarObjects1.length = 0;
gdjs.LevelsCode.GDStarObjects2.length = 0;
gdjs.LevelsCode.GDStarObjects3.length = 0;
gdjs.LevelsCode.GDStarObjects4.length = 0;
gdjs.LevelsCode.GDStarObjects5.length = 0;
gdjs.LevelsCode.GDRopeObjects1.length = 0;
gdjs.LevelsCode.GDRopeObjects2.length = 0;
gdjs.LevelsCode.GDRopeObjects3.length = 0;
gdjs.LevelsCode.GDRopeObjects4.length = 0;
gdjs.LevelsCode.GDRopeObjects5.length = 0;
gdjs.LevelsCode.GDSpidermanObjects1.length = 0;
gdjs.LevelsCode.GDSpidermanObjects2.length = 0;
gdjs.LevelsCode.GDSpidermanObjects3.length = 0;
gdjs.LevelsCode.GDSpidermanObjects4.length = 0;
gdjs.LevelsCode.GDSpidermanObjects5.length = 0;
gdjs.LevelsCode.GDFinishObjects1.length = 0;
gdjs.LevelsCode.GDFinishObjects2.length = 0;
gdjs.LevelsCode.GDFinishObjects3.length = 0;
gdjs.LevelsCode.GDFinishObjects4.length = 0;
gdjs.LevelsCode.GDFinishObjects5.length = 0;
gdjs.LevelsCode.GDCityBackgroundObjects1.length = 0;
gdjs.LevelsCode.GDCityBackgroundObjects2.length = 0;
gdjs.LevelsCode.GDCityBackgroundObjects3.length = 0;
gdjs.LevelsCode.GDCityBackgroundObjects4.length = 0;
gdjs.LevelsCode.GDCityBackgroundObjects5.length = 0;
gdjs.LevelsCode.GDBrickObjects1.length = 0;
gdjs.LevelsCode.GDBrickObjects2.length = 0;
gdjs.LevelsCode.GDBrickObjects3.length = 0;
gdjs.LevelsCode.GDBrickObjects4.length = 0;
gdjs.LevelsCode.GDBrickObjects5.length = 0;
gdjs.LevelsCode.GDBluePanelObjects1.length = 0;
gdjs.LevelsCode.GDBluePanelObjects2.length = 0;
gdjs.LevelsCode.GDBluePanelObjects3.length = 0;
gdjs.LevelsCode.GDBluePanelObjects4.length = 0;
gdjs.LevelsCode.GDBluePanelObjects5.length = 0;
gdjs.LevelsCode.GDEffectsSliderObjects1.length = 0;
gdjs.LevelsCode.GDEffectsSliderObjects2.length = 0;
gdjs.LevelsCode.GDEffectsSliderObjects3.length = 0;
gdjs.LevelsCode.GDEffectsSliderObjects4.length = 0;
gdjs.LevelsCode.GDEffectsSliderObjects5.length = 0;
gdjs.LevelsCode.GDMusicSliderObjects1.length = 0;
gdjs.LevelsCode.GDMusicSliderObjects2.length = 0;
gdjs.LevelsCode.GDMusicSliderObjects3.length = 0;
gdjs.LevelsCode.GDMusicSliderObjects4.length = 0;
gdjs.LevelsCode.GDMusicSliderObjects5.length = 0;

gdjs.LevelsCode.eventsList21(runtimeScene);

return;

}

gdjs['LevelsCode'] = gdjs.LevelsCode;
